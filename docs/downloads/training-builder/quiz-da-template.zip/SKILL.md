---
name: quiz-da-template
description: Crea un quiz di verifica partendo dal template TPL-TRN-002, da un documento sorgente, da un'agenda di corso o da un argomento tecnico. Usala per quiz, test e autovalutazioni.
---

# Quiz da template (TPL-TRN-002)

Questa skill produce un quiz completo, con chiave di correzione e spiegazioni, compilando la struttura del template TPL-TRN-002 a partire da un documento sorgente, da un'agenda di corso o da un argomento tecnico.

## Quando usarla

- L'utente chiede un quiz, un test, una verifica o un'autovalutazione.
- L'utente fornisce un documento o un'agenda da cui ricavare le domande.
- Serve un quiz intermedio, finale o di richiamo a distanza per un corso.

## Input da raccogliere

Leggi prima il sorgente. Ricava o chiedi solo i dati mancanti essenziali:

1. Documento sorgente, agenda o argomento
2. Tipologia: intermedio, finale, autovalutazione, richiamo a distanza
3. Numero di domande e durata (se non indicati: 10 domande, circa 1 minuto per domanda a scelta)
4. Livello di difficoltà e soglia di superamento (se non indicata: 70%)

Se un dato non essenziale manca, scegli un valore ragionevole, dichiaralo in una riga in fondo e prosegui. Fai al massimo una domanda, solo se manca il sorgente o l'argomento.

## Struttura da produrre (template TPL-TRN-002)

1. **Scheda del quiz**: titolo, codice, corso di riferimento, moduli coperti, tipologia, numero domande, durata, soglia, punteggio, tentativi consentiti, documento sorgente, difficoltà
2. **Istruzioni per i partecipanti**: numero domande, durata, indicazione delle domande a risposta multipla, soglia di superamento
3. **Distribuzione delle domande**: tabella Obiettivo, Livello cognitivo (ricordare, comprendere, applicare, analizzare), N. domande, Peso. Per un quiz finale: circa 30% ricordare e comprendere, 50% applicare, 20% analizzare
4. **Domande**, nei formati: scelta singola, scelta multipla, vero o falso, completamento, caso pratico. Ogni domanda riporta obiettivo collegato, difficoltà, punti, testo, opzioni, risposta corretta, spiegazione e fonte
5. **Chiave di correzione**: tabella N., Tipo, Risposta corretta, Punti, Obiettivo; punteggio massimo e soglia in punti
6. **Feedback per fascia di punteggio**: sotto soglia (con moduli da rivedere), sufficiente, ottimo
7. **Esportazione e uso**: versione docente (con chiave e spiegazioni), versione partecipanti (solo domande), eventuali varianti con ordine diverso

## Regole di scrittura delle domande

- Una sola idea per domanda, formulata in positivo e senza doppie negazioni.
- I distrattori sono plausibili e riferiti a errori comuni, mai assurdi.
- Evitare "tutte le precedenti", "nessuna delle precedenti" e indizi grammaticali che rivelino la risposta.
- Opzioni di lunghezza simile; la posizione della risposta corretta è distribuita in modo vario.
- Ogni risposta corretta deve essere verificabile nel sorgente. Se serve conoscenza esterna, segnalarlo nel campo Fonte.
- Ogni obiettivo di apprendimento ha almeno una domanda.
- Nessuna domanda deve suggerire la risposta di un'altra.
- Durata realistica: circa 1 minuto per domanda a scelta, da 3 a 4 minuti per un caso pratico.
- Non lasciare segnaposto `{{...}}` non compilati.

## Output

- Formato predefinito: documento Word (.docx). Se l'utente chiede Markdown, PDF, o un formato importabile in LMS, usa quello.
- Se utile, produci due versioni: docente (con chiave e spiegazioni) e partecipanti (solo domande).
- Rimuovere dal documento finale tutte le note di istruzione per l'agente.
- Chiudere con 1 o 2 righe di sintesi (numero domande, durata, soglia, ipotesi fatte), senza ripetere il contenuto.

## Checklist finale (verificare prima di consegnare)

- [ ] Ogni obiettivo ha almeno una domanda
- [ ] Ogni domanda ha risposta corretta, spiegazione e fonte
- [ ] Numero domande e punteggio totale coincidono con la scheda
- [ ] La risposta corretta non ricade sempre nella stessa posizione
- [ ] Nessuna domanda dà la risposta a un'altra
- [ ] La durata è realistica
- [ ] Nessun segnaposto non compilato

## Collegamento con l'agenda

Se esiste un'agenda generata con la skill `agenda-corso-da-template`, usa gli stessi numeri di obiettivo e moduli, e rendi gli identificativi delle domande coerenti con la matrice obiettivi, moduli e verifiche dell'agenda.