---
name: policy-answer-checklist
description: Invoke for every employee question about leave, welfare, business travel, or internal procedures to verify authoritative SharePoint policies and produce a cited, policy-grounded answer.
---

## Purpose
Apply a mandatory evidence and quality checklist whenever answering employee questions about leave, welfare, business travel, or internal procedures.

## Uses
- Agent capabilities: searchOneDriveAndSharePoint
- Agent knowledge sources: authoritative internal policies and procedures stored in SharePoint

## Instructions
1. **Classify the request.** Identify the policy area, employee population, country or office, relevant dates, and the specific decision or procedure requested. Ask only for missing details that could materially change the answer.
2. **Find authoritative evidence.** Search SharePoint for the applicable policy, procedure, FAQ, form, or official HR guidance. Prefer documents owned by the responsible function and clearly marked as approved or published.
3. **Validate each source.** Before using a document, verify its title, owner or publishing function, approval or publication status, effective date, review date when available, version, and applicability to the user's population and location.
4. **Check currency and conflicts.** Compare potentially relevant documents. Prefer the newest effective authoritative version. If two sources conflict or the current version cannot be established, state the conflict and do not present an uncertain rule as definitive.
5. **Build the answer from evidence.** Give the direct answer first, then summarize eligibility, limits, required steps, deadlines, approvals, forms, and exceptions that are supported by the validated sources.
6. **Cite material claims.** For every substantive policy statement, cite the SharePoint document by title and provide its clickable link. Include the effective date or version when available. Never cite a document that was not used to support the statement.
7. **Apply the completion gate.** Before responding, confirm that the answer addresses the user's question, every material claim has a citation, dates and scope are consistent, exceptions are visible, and no unsupported assumptions remain.
8. **Handle missing evidence.** If no valid source is found, say that the answer cannot be confirmed from the available policies, list what was searched, and direct the user to the responsible internal function rather than guessing.

## Parameters
- Employee question
- Relevant country, office, employee group, and dates when known
- Available SharePoint policy and procedure content

## Output
A concise Italian answer with: direct guidance, applicable steps or conditions, exceptions or uncertainties, and inline clickable citations to the validated SharePoint documents.