---
name: gdpr-compliance-check
description: Invoke this skill whenever the user requests a GDPR compliance assessment, mandatory control checklist, gap analysis, remediation review, or periodic verification of privacy obligations.
---

## Purpose
Apply a mandatory GDPR compliance checklist and produce an evidence-based gap assessment.

## Uses
- Agent knowledge sources: official GDPR document in the knowledge base
- Agent capabilities: webBrowsing
- External authoritative sources: EUR-Lex GDPR, European Data Protection Board guidance, Italian Garante

## Instructions
1. Define the assessment scope and identify missing material information.
2. Always consult the official GDPR document in the agent knowledge base before assessing controls.
3. Treat that document as the primary source for articles, recitals, definitions, obligations, and deadlines.
4. For every applicable checklist item, cite the relevant article or recital from the knowledge-base document.
5. Verify current guidance and later developments against official EU, EDPB, and Italian Garante sources.
6. If sources conflict, report the discrepancy and distinguish binding law, authority guidance, and good practice.
7. Assess governance, Article 30 records, principles, lawful bases, transparency, rights, processors, transfers, privacy by design, DPIA, security, breaches, retention, special data, children, cookies, marketing, monitoring, profiling, and automated decisions where applicable.
8. Mark each item Compliant, Partially compliant, Non-compliant, Not applicable, or Not assessed; record evidence, owner, date, legal reference, gap, risk, and remediation.
9. Never mark a control compliant without evidence; flag missing evidence separately from confirmed non-compliance.
10. Validate that each gap has an owner, priority, action, and target date, and escalate high-risk matters for DPO or legal review.
11. Produce an executive summary, completion percentage excluding Not applicable items, prioritized findings, full checklist, remediation plan, source references, and last-checked date.

## Parameters
- Scope, jurisdiction, organization or process details
- Available compliance evidence and review period
- Optional risk method and remediation deadlines

## Output
A structured GDPR checklist with evidence, references to the official knowledge-base document, risk, ownership, remediation, deadlines, summary, and validation notes.