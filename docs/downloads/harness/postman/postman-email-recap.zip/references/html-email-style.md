# Stile del corpo email

- Il template restituisce un frammento HTML, non un documento con tag `<html>`, `<head>` o `<body>`.
- Usa Arial/Helvetica, testo scuro, dimensione 14 px e interlinea 1,5.
- Mantieni una struttura semantica semplice: paragrafi, titoli, elenchi, tabelle e link.
- Usa solo stili inline compatibili con i client email.
- Il generatore esegue l’escape del testo e convalida i link; non inserire HTML grezzo o codice.
- Non aggiungere immagini remote, script, moduli, firme o branding non forniti.
