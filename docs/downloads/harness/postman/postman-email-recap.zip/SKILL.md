---
name: postman-email-recap
description: "Prepara il corpo HTML di un riepilogo email fedele alla risposta selezionata e genera il file nella sandbox."
---

# Postman Email Recap

Usa questa skill quando l’utente chiede esplicitamente di inviare via email una risposta della conversazione, oppure quando un agente chiamante trasmette chiaramente tale richiesta.

## Selezione del contenuto

1. Usa solo il testo o lo storico effettivamente fornito nel contesto. Se operi come agente connesso, non presumere di vedere messaggi non passati dal chiamante.
2. Seleziona la risposta finale dell’assistente che corrisponde alla richiesta. Se il contenuto è ambiguo o manca, chiedi quale risposta inoltrare.
3. Non riassumere, parafrasare, correggere o aggiungere fatti. Mantieni titoli, paragrafi, elenchi, tabelle semplici e hyperlink.

## Generazione del corpo HTML

1. Rappresenta la risposta selezionata come JSON strutturato usando lo schema in `references/email-body-input.example.json`.
2. Non inserire HTML grezzo nel JSON. Usa `text` o `segments`; per i link usa `url` solo con indirizzi `https`, `http` o `mailto` già presenti nel contenuto originale.
3. Esegui lo script `scripts/render_email_body.py` nella sandbox Python:

   ```text
   python scripts/render_email_body.py --input email_body.json --output email_body.html
   ```

4. Verifica che il file HTML sia stato prodotto e leggilo come input per il connettore email. Lo script usa il template `references/email-body-template.html`, codifica il testo e rifiuta schemi di link non ammessi.
5. Se l’esecuzione fallisce, segnala l’errore; non dichiarare generato il corpo e non inviare email.

## Preparazione e invio

- **To**: usa l’indirizzo del richiedente solo se è esplicitamente disponibile nel contesto runtime o confermato dall’utente. Se manca, chiedilo e attendi conferma; non dedurre indirizzi.
- **Subject**: massimo 8 parole, sintetico e pertinente; non citare HTML o formattazione.
- **Body**: passa l’intero contenuto di `email_body.html`, senza aggiunte.
- Chiama il connettore di invio una sola volta e soltanto dopo una richiesta esplicita, con contenuto e destinatario verificati.
- Se l’invio fallisce o l’esito è incerto, non dichiarare successo e non riprovare automaticamente.

Non inviare email proattivamente, allegati o destinatari in CC/BCC. Dopo un invio confermato, fornisci una breve conferma senza riprodurre lo storico completo.
