"""Render a safe, email-ready HTML fragment from structured JSON content."""

from __future__ import annotations

import argparse
import html
import json
from pathlib import Path
from string import Template
from typing import Any
from urllib.parse import urlsplit


TEMPLATE_PATH = Path(__file__).resolve().parents[1] / "references" / "email-body-template.html"
ALLOWED_LINK_SCHEMES = {"http", "https", "mailto"}


def escape_text(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("I campi testuali devono essere stringhe.")
    return html.escape(value, quote=False)


def safe_url(value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Ogni URL deve essere una stringa non vuota.")
    url = value.strip()
    try:
        parsed = urlsplit(url)
    except ValueError as exc:
        raise ValueError("URL non valido nel contenuto email.") from exc
    if parsed.scheme.lower() not in ALLOWED_LINK_SCHEMES:
        raise ValueError("Sono ammessi solo link http, https o mailto.")
    if parsed.scheme.lower() in {"http", "https"} and not parsed.netloc:
        raise ValueError("Il link http/https deve includere un host.")
    if parsed.scheme.lower() == "mailto" and not parsed.path:
        raise ValueError("Il link mailto deve includere un indirizzo.")
    return url


def render_segments(segments: Any) -> str:
    if not isinstance(segments, list):
        raise ValueError("segments deve essere una lista.")
    rendered: list[str] = []
    for segment in segments:
        if not isinstance(segment, dict):
            raise ValueError("Ogni segmento deve essere un oggetto JSON.")
        text = escape_text(segment.get("text", ""))
        url = segment.get("url")
        if url is not None:
            href = html.escape(safe_url(url), quote=True)
            rendered.append(
                f'<a href="{href}" style="color:#1a73e8;text-decoration:none;">{text}</a>'
            )
        else:
            rendered.append(text)
    return "".join(rendered)


def render_inline(value: Any) -> str:
    if isinstance(value, str):
        return escape_text(value)
    if isinstance(value, list):
        return render_segments(value)
    raise ValueError("Il testo di un blocco deve essere una stringa o una lista di segmenti.")


def render_list(block: dict[str, Any], tag: str) -> str:
    items = block.get("items")
    if not isinstance(items, list) or not items:
        raise ValueError("Un blocco lista deve contenere almeno un elemento.")
    list_items = "".join(f"<li>{render_inline(item)}</li>" for item in items)
    return f'<{tag} style="margin:10px 0;padding-left:22px;">{list_items}</{tag}>'


def render_table(block: dict[str, Any]) -> str:
    headers = block.get("headers", [])
    rows = block.get("rows")
    if not isinstance(headers, list) or not isinstance(rows, list) or not rows:
        raise ValueError("Una tabella deve contenere righe e headers deve essere una lista.")
    if headers and any(not isinstance(row, list) or len(row) != len(headers) for row in rows):
        raise ValueError("Ogni riga deve avere lo stesso numero di celle delle intestazioni.")

    header_html = ""
    if headers:
        cells = "".join(
            '<th style="background-color:#f1f3f4;text-align:left;padding:8px;'
            f'border:1px solid #dddddd;">{render_inline(cell)}</th>'
            for cell in headers
        )
        header_html = f"<thead><tr>{cells}</tr></thead>"

    row_html = []
    for row in rows:
        if not isinstance(row, list):
            raise ValueError("Ogni riga della tabella deve essere una lista.")
        cells = "".join(
            '<td style="padding:8px;border:1px solid #dddddd;">'
            f"{render_inline(cell)}</td>"
            for cell in row
        )
        row_html.append(f"<tr>{cells}</tr>")
    return (
        '<table style="border-collapse:collapse;width:100%;margin:15px 0;">'
        f"{header_html}<tbody>{''.join(row_html)}</tbody></table>"
    )


def render_block(block: Any) -> str:
    if not isinstance(block, dict):
        raise ValueError("Ogni blocco deve essere un oggetto JSON.")
    block_type = block.get("type")
    if block_type == "paragraph":
        content = render_inline(block.get("segments", block.get("text", "")))
        return f'<p style="margin:0 0 12px 0;">{content}</p>'
    if block_type == "heading":
        level = block.get("level", 2)
        if not isinstance(level, int) or isinstance(level, bool) or level not in {1, 2, 3}:
            raise ValueError("level per un heading deve essere 1, 2 o 3.")
        content = render_inline(block.get("segments", block.get("text", "")))
        return (
            f'<h{level} style="color:#1a73e8;margin:18px 0 10px 0;">'
            f"{content}</h{level}>"
        )
    if block_type == "unordered_list":
        return render_list(block, "ul")
    if block_type == "ordered_list":
        return render_list(block, "ol")
    if block_type == "table":
        return render_table(block)
    if block_type == "quote":
        content = render_inline(block.get("segments", block.get("text", "")))
        return (
            '<blockquote style="margin:12px 0;padding:8px 12px;'
            f'border-left:3px solid #dadce0;color:#5f6368;">{content}</blockquote>'
        )
    raise ValueError(f"Tipo di blocco non supportato: {block_type!r}.")


def render_email_body(data: dict[str, Any], template_path: Path = TEMPLATE_PATH) -> str:
    if not isinstance(data, dict):
        raise ValueError("Il JSON di input deve contenere un oggetto.")
    blocks = data.get("blocks")
    if not isinstance(blocks, list) or not blocks:
        raise ValueError("Il campo blocks deve contenere almeno un blocco.")

    display_name = data.get("display_name", "")
    if not isinstance(display_name, str):
        raise ValueError("display_name deve essere una stringa.")
    display_name = display_name.strip()
    greeting = "Ciao," if not display_name else f"Ciao {display_name},"

    intro = data.get("intro", "Ecco le informazioni richieste:")
    if not isinstance(intro, str) or not intro.strip():
        raise ValueError("intro deve essere una stringa non vuota.")

    template_text = template_path.read_text(encoding="utf-8")
    template = Template(template_text)
    return template.substitute(
        greeting=escape_text(greeting),
        intro=escape_text(intro.strip()),
        content="".join(render_block(block) for block in blocks),
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Genera un frammento HTML email-safe da un file JSON strutturato."
    )
    parser.add_argument("--input", required=True, type=Path, help="Percorso del file JSON.")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("email_body.html"),
        help="Percorso del file HTML generato.",
    )
    parser.add_argument(
        "--template",
        type=Path,
        default=TEMPLATE_PATH,
        help="Percorso del template HTML.",
    )
    args = parser.parse_args()

    with args.input.open("r", encoding="utf-8") as input_file:
        data = json.load(input_file)
    body = render_email_body(data, args.template)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(body, encoding="utf-8")
    print(f"Corpo email HTML creato: {args.output}")


if __name__ == "__main__":
    main()
