---
name: applicant-teams-notification
description: "Invia al canale Applicant una notifica minima e verificabile tramite il workflow Teams collegato."
---

# Skill: Applicant Teams Notification

## Quando usarla
Usa questa skill solo se HR chiede una notifica oppure se il trigger email configurato dall’utente fornisce i campi `ResumeLink` e `ResumeName`.

## Prerequisiti
- `ResumeLink`: link SharePoint del CV, già creato con accesso di sola lettura limitato agli utenti dell’organizzazione.
- `ResumeName`: nome file del CV.
Se uno dei due manca, non inventarlo, non costruire un link e non chiamare il workflow.

## Invio
1. Chiama `Notify Teams Applicant channel` con `text` = `ResumeLink` e `text_1` = `ResumeName`.
2. Non inviare il contenuto del CV, dati non necessari o link pubblici/esterni.
3. Conferma l’invio solo se il workflow termina con esito `Finished`; altrimenti riporta l’errore o l’esito non verificato.
4. La notifica non equivale a screening, graduatoria o decisione di assunzione.
