---
name: nis2-compliance-assessment
description: Invoke when assessing or monitoring an organization's NIS2 compliance against the authoritative PDF in the agent knowledge base and current official Italian and EU regulatory updates.
---

## Purpose
Evaluate and monitor NIS2 compliance using the authoritative NIS2 PDF available in the parent agent's knowledge sources, while checking current official EU and Italian regulatory publications. Invoke for initial assessments, periodic reviews, gap analyses, remediation tracking, evidence reviews, and regulatory-change impact assessments.

## Uses
- Agent knowledge sources: the attached complete NIS2 legislation PDF.
- Agent capabilities: web browsing for current official publications from EUR-Lex, Gazzetta Ufficiale, Normattiva, and ACN.

## Instructions
1. **Establish scope and legal baseline**
   - Identify the organization, legal entities, countries, sectors, services, size, and whether the assessment concerns an essential or important entity.
   - Read the attached NIS2 PDF before assessing compliance. Record its title, version, publication date, jurisdiction, and relevant articles or annexes.
   - For Italy, distinguish the Directive (EU) 2022/2555 from its national implementation, including Legislative Decree 138/2024 and applicable ACN determinations, specifications, guidance, and deadlines.
   - If organizational facts are missing, mark the related checks as `Da verificare`; do not infer compliance.

2. **Verify regulatory currency**
   - Check only official sources: EUR-Lex, Gazzetta Ufficiale, Normattiva, and ACN.
   - Compare publication and effective dates against the attached PDF and identify amendments, implementing acts, determinations, guidance, deadlines, or superseding provisions.
   - For every regulatory update, capture title, issuing authority, publication date, effective date, affected obligations, affected entity categories, and official link.
   - Treat guidance as non-binding unless the source states otherwise, and clearly distinguish legal obligations from recommendations.

3. **Apply the NIS2 compliance checklist**
   Assess each control below as `Conforme`, `Parzialmente conforme`, `Non conforme`, `Non applicabile`, or `Da verificare`. For every item record legal basis, evidence reviewed, finding, gap, owner, priority, target date, and remediation action.

   **A. Applicability and registration**
   - Legal-entity perimeter, sector/subsector, services provided, size-cap rule, exceptions, jurisdiction, essential/important classification, and group dependencies.
   - Registration or annual update with ACN, required organizational and technical information, contact point and deputy, IP ranges/domains, and evidence of submissions.
   - Deadlines, notifications received from ACN, and changes requiring prompt updates.

   **B. Governance and management accountability**
   - Formal approval and oversight of cybersecurity risk-management measures by management bodies.
   - Defined roles, delegations, decision rights, reporting lines, budget, risk acceptance, and escalation.
   - Cybersecurity training for management and role-based workforce awareness.
   - Periodic management reporting, documented decisions, and accountability evidence.

   **C. Risk-management framework**
   - Documented, proportionate, all-hazards risk methodology covering confidentiality, integrity, availability, authenticity, physical/environmental threats, and dependencies.
   - Inventory and classification of services, processes, information, systems, networks, identities, data flows, facilities, and third parties.
   - Threat, vulnerability, likelihood, impact, treatment, residual-risk acceptance, review cadence, and change triggers.
   - Alignment between risk assessment, business impact analysis, controls, and remediation plan.

   **D. Security policies and control governance**
   - Approved policies for information security, acceptable use, access, assets, cryptography, logging, vulnerability, incident, continuity, suppliers, development, and change.
   - Policy ownership, versioning, exception handling, review, communication, and compliance monitoring.
   - Mapping to applicable ACN basic security measures and evidence requirements.

   **E. Incident prevention, detection, response, and notification**
   - Incident taxonomy, severity and significance criteria, roles, playbooks, evidence preservation, communications, and lessons learned.
   - Monitoring, logging, alerting, correlation, time synchronization, retention, and coverage of relevant systems.
   - CSIRT Italia contact and reporting process, including early warning, incident notification, intermediate updates when required, and final report within applicable legal deadlines.
   - Exercise records, post-incident improvements, and coordination with privacy, legal, communications, customers, and suppliers.

   **F. Business continuity and crisis management**
   - Business impact analysis, recovery objectives, continuity and disaster-recovery plans, backups, redundancy, crisis organization, and emergency communications.
   - Backup immutability/offline protection, restoration tests, alternate processing, dependency failure scenarios, and exercise results.
   - Alignment of recovery capabilities with critical-service requirements and risk assessment.

   **G. Supply-chain and supplier security**
   - Supplier inventory, criticality and concentration risk, due diligence, risk assessment, selection, onboarding, monitoring, and exit.
   - Security clauses covering incident notification, vulnerabilities, audit rights, subcontractors, data handling, resilience, access, and termination.
   - Identification and reporting of relevant suppliers where required by ACN.
   - Risks arising from managed service providers, cloud providers, software, hardware, and remote support.

   **H. Secure acquisition, development, and maintenance**
   - Security requirements throughout acquisition and system/software development life cycles.
   - Secure design, code review, testing, separation of environments, change control, release approval, secrets management, and component provenance.
   - Vulnerability disclosure and coordinated vulnerability handling.

   **I. Vulnerability, configuration, and patch management**
   - Asset coverage, scanning, penetration testing, threat intelligence, prioritization, remediation SLAs, exceptions, and verification.
   - Secure baselines, hardening, configuration monitoring, unsupported technology, and exposure management.
   - Processes for receiving, assessing, and remediating supplier and CERT/CSIRT advisories.

   **J. Identity and access management**
   - Joiner/mover/leaver controls, least privilege, segregation of duties, privileged access management, periodic reviews, and service accounts.
   - Multi-factor or continuous authentication where appropriate, secure credential management, remote access, and access logging.
   - Physical access controls for relevant facilities and equipment.

   **K. Cryptography and communications security**
   - Encryption in transit and at rest, key and certificate lifecycle, approved algorithms, ownership, rotation, revocation, and recovery.
   - Secure voice, video, messaging, and emergency communications where appropriate.

   **L. Human resources security and awareness**
   - Pre-employment, contractual, onboarding, role-change, termination, disciplinary, confidentiality, and acceptable-use controls.
   - Phishing and social-engineering awareness, role-specific training, competence tracking, and effectiveness testing.

   **M. Network, endpoint, cloud, and operational security**
   - Segmentation, boundary protection, secure administration, endpoint protection, email/web controls, DNS security, remote access, and mobile-device security.
   - Cloud shared-responsibility controls, tenant configuration, logging, resilience, data location, and service-provider dependencies.
   - Capacity, availability, maintenance, malware protection, removable media, and secure disposal.

   **N. Measurement, testing, and assurance**
   - Control effectiveness metrics, internal audit, independent assessment, technical testing, management review, corrective actions, and closure verification.
   - Evidence is current, attributable, complete, retained, and traceable to each requirement.
   - Previous findings and accepted risks are reviewed for age, status, and continuing validity.

   **O. Cooperation, information sharing, and records**
   - Procedures for voluntary cybersecurity information sharing and participation in trusted communities where appropriate.
   - Records supporting regulatory requests, inspections, supervision, and enforcement.
   - Data-protection, confidentiality, legal privilege, and need-to-know controls for shared information.

4. **Validate evidence and findings**
   - Accept a control as `Conforme` only when evidence is specific, current, attributable, and demonstrates both design and operation.
   - Mark missing, stale, contradictory, sampled-only, or unverifiable evidence explicitly.
   - Cite the exact PDF article/page or official provision supporting each finding; never invent citations.
   - Separate mandatory requirements, ACN implementation specifications, and improvement recommendations.
   - Apply proportionality based on entity category, service criticality, exposure, size, and actual risk without weakening explicit obligations.

5. **Prioritize remediation**
   - Rate gaps as `Critica`, `Alta`, `Media`, or `Bassa` using legal deadline, service impact, exploitability, incident exposure, and supervisory risk.
   - Identify quick wins, dependencies, accountable owner, target date, required evidence, and acceptance criteria.
   - Highlight overdue statutory or ACN deadlines separately from general control gaps.

6. **Produce the assessment**
   - Begin with scope, sources, document versions, assessment date, assumptions, and limitations.
   - Provide an executive summary with applicability, overall posture, highest risks, overdue obligations, and immediate actions.
   - Provide the full checklist table and a prioritized remediation roadmap.
   - Add a regulatory-change register when monitoring updates, showing old requirement, new requirement, effective date, impact, and required action.
   - Close with unresolved questions and the next review date.

## Parameters
- Organization and legal entities in scope.
- Sector, services, size, geography, and known NIS classification.
- Attached NIS2 legislation PDF from the agent knowledge base.
- Available policies, procedures, inventories, risk assessments, contracts, logs, reports, test results, and prior findings.
- Assessment date, desired reporting period, and preferred output depth.

## Output
- A source-grounded NIS2 applicability assessment.
- A complete control checklist with status, legal basis, evidence, findings, gaps, ownership, priorities, and deadlines.
- A prioritized remediation plan and executive summary.
- For monitoring requests, a regulatory-change register with official links and impact analysis.