var TRV = window.TRV || {};
(function (ns) {
  "use strict";
  var STATO_APERTA = 100000000;
  var ESITO_ATTESA = 100000000, ESITO_APPROVATA = 100000001, ESITO_RESPINTA = 100000002;
  var emailUtente = null;
  var TEAM_MANAGER = "Zava Trasferte Manager";
  var isManager = null;

  ns.eManager = function () {
    if (isManager !== null) { return Promise.resolve(isManager); }
    var id = Xrm.Utility.getGlobalContext().userSettings.userId.replace(/[{}]/g, "");
    return Xrm.WebApi.retrieveMultipleRecords("team",
      "?$select=teamid&$filter=name eq '" + TEAM_MANAGER + "' and teammembership_association/any(u:u/systemuserid eq " + id + ")"
    ).then(function (r) { isManager = r.entities.length > 0; return isManager; },
           function () { isManager = false; return false; });
  };

  function valore(fc, campo) {
    var a = fc.getAttribute(campo);
    return a ? a.getValue() : null;
  }

  function notifica(fc, testo, livello) {
    fc.ui.setFormNotification(testo, livello || "INFO", "trv_cmd");
    setTimeout(function () { fc.ui.clearFormNotification("trv_cmd"); }, 6000);
  }

  function leggiEmailUtente() {
    if (emailUtente !== null) { return Promise.resolve(emailUtente); }
    var id = Xrm.Utility.getGlobalContext().userSettings.userId.replace(/[{}]/g, "");
    return Xrm.WebApi.retrieveRecord("systemuser", id, "?$select=internalemailaddress").then(function (u) {
      emailUtente = (u.internalemailaddress || "").toLowerCase();
      return emailUtente;
    }, function () { emailUtente = ""; return ""; });
  }

  ns.puoInviare = function (fc) {
    if (!fc || fc.ui.getFormType() === 1) { return false; }
    return valore(fc, "trv_stato") === STATO_APERTA && valore(fc, "trv_richiestainvio") !== true;
  };

  ns.invia = function (fc) {
    Xrm.Navigation.openConfirmDialog({
      title: "Invia per approvazione",
      text: "Inviare la trasferta per approvazione? Il gestore viene scelto in base al tuo reparto.",
      confirmButtonLabel: "Invia",
      cancelButtonLabel: "Annulla"
    }).then(function (r) {
      if (!r.confirmed) { return; }
      fc.getAttribute("trv_richiestainvio").setValue(true);
      fc.data.save().then(function () {
        notifica(fc, "Richiesta inviata. Il gestore riceverà una notifica su Teams.", "INFO");
        fc.ui.refreshRibbon();
      }, function (e) { notifica(fc, "Errore durante l'invio: " + e.message, "ERROR"); });
    });
  };

  ns.inviaDaGriglia = function (grid) {
    var righe = grid.getGrid().getSelectedRows();
    if (righe.getLength() !== 1) { return; }
    var id = righe.get(0).getData().getEntity().getId().replace(/[{}]/g, "");
    Xrm.WebApi.retrieveRecord("trv_trasferta", id, "?$select=trv_stato,trv_richiestainvio,trv_name").then(function (t) {
      if (t.trv_stato !== STATO_APERTA || t.trv_richiestainvio === true) {
        Xrm.Navigation.openAlertDialog({ title: "Invia per approvazione", text: "Si possono inviare solo trasferte in stato Aperta." });
        return;
      }
      Xrm.Navigation.openConfirmDialog({
        title: "Invia per approvazione",
        text: "Inviare \"" + t.trv_name + "\" per approvazione? Il gestore viene scelto in base al reparto del richiedente.",
        confirmButtonLabel: "Invia",
        cancelButtonLabel: "Annulla"
      }).then(function (r) {
        if (!r.confirmed) { return; }
        Xrm.WebApi.updateRecord("trv_trasferta", id, { trv_richiestainvio: true }).then(function () {
          Xrm.Navigation.openAlertDialog({ title: "Richiesta inviata", text: "Il gestore riceverà una notifica su Teams." });
          grid.refresh();
        }, function (e) {
          Xrm.Navigation.openAlertDialog({ title: "Errore", text: e.message });
        });
      });
    });
  };

  ns.puoDecidere = function (fc) {
    if (!fc || fc.ui.getFormType() === 1) { return false; }
    if (valore(fc, "trv_esito") !== ESITO_ATTESA) { return false; }
    var approvatore = (valore(fc, "trv_emailapprovatore") || "").toLowerCase();
    return Promise.all([leggiEmailUtente(), ns.eManager()]).then(function (r) {
      return r[1] === true && approvatore !== "" && approvatore === r[0];
    });
  };

  function registra(fc, esito, messaggio) {
    fc.getAttribute("trv_esito").setValue(esito);
    fc.getAttribute("trv_datarisposta").setValue(new Date());
    fc.data.save().then(function () {
      notifica(fc, messaggio, esito === ESITO_APPROVATA ? "INFO" : "WARNING");
      fc.ui.refreshRibbon();
    }, function (e) { notifica(fc, "Errore durante il salvataggio: " + e.message, "ERROR"); });
  }

  ns.approva = function (fc) {
    Xrm.Navigation.openConfirmDialog({
      title: "Approva richiesta",
      text: "Confermi l'approvazione della trasferta?",
      confirmButtonLabel: "Approva",
      cancelButtonLabel: "Annulla"
    }).then(function (r) { if (r.confirmed) { registra(fc, ESITO_APPROVATA, "Richiesta approvata."); } });
  };

  ns.respingi = function (fc) {
    var commento = valore(fc, "trv_commento");
    if (!commento || !commento.trim()) {
      notifica(fc, "Scrivi il motivo nel campo Commento, poi premi Respingi.", "ERROR");
      var c = fc.getControl("trv_commento");
      if (c) { c.setFocus(); }
      return;
    }
    Xrm.Navigation.openConfirmDialog({
      title: "Respingi richiesta",
      text: "Confermi di respingere la trasferta?",
      confirmButtonLabel: "Respingi",
      cancelButtonLabel: "Annulla"
    }).then(function (r) { if (r.confirmed) { registra(fc, ESITO_RESPINTA, "Richiesta respinta."); } });
  };
})(TRV);
window.TRV = TRV;
