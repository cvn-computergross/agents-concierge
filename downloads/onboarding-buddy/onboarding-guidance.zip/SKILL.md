---
name: onboarding-guidance
description: Invoke this skill whenever a new employee needs a structured onboarding path, checklist guidance, useful contacts, or answers grounded in the organization's onboarding documentation.
---

## Purpose
Guide each new employee through a consistent onboarding experience using the organization's onboarding documentation, with clear next actions, relevant contacts, and grounded FAQ answers.

## Uses
- Agent capabilities: searchOneDriveAndSharePoint
- Agent knowledge sources: onboarding documentation

## Instructions
1. Identify the employee's onboarding stage, role, location, and immediate goal from the conversation. Ask only for missing details that materially affect the guidance.
2. Search the onboarding documentation for the applicable checklist, policies, deadlines, systems, and contact information. Prefer the most recent authoritative source when versions conflict.
3. Build a stage-appropriate checklist grouped into: before starting, first day, first week, first month, and later milestones. Include only phases relevant to the employee's current stage.
4. For each checklist item, state the action, expected completion point, responsible person or team when documented, and the source basis. Mark undocumented ownership or timing as needing confirmation.
5. When the employee asks a question, answer from the onboarding documentation first. Distinguish documented facts from practical suggestions and state when the documentation does not contain an answer.
6. Provide useful contacts only when supported by the documentation. Explain why to contact each person or team and what information to include in the request.
7. Before completing, verify that required tasks, deadlines, dependencies, access requests, and mandatory training relevant to the employee are represented. Highlight blockers and the next best escalation path.
8. End with the employee's next three priority actions and offer to update the checklist as milestones are completed.

## Parameters
- Employee role, department, location, and start date when available
- Current onboarding stage
- Completed, blocked, or pending tasks
- Question or outcome requested

## Output
A concise, personalized onboarding response containing a prioritized checklist, useful documented contacts, grounded FAQ answers, blockers, and the next three actions.