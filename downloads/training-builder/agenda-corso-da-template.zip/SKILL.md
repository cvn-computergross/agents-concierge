---
name: agenda-corso-da-template
description: Crea l'agenda di un corso partendo dal template TPL-TRN-001, da un documento sorgente o da un argomento tecnico. Usala per agende, programmi formativi e piani di corso.
---

# Agenda corso da template (TPL-TRN-001)

Questa skill produce un'agenda di corso completa e coerente, compilando la struttura del template TPL-TRN-001 a partire da un documento sorgente allegato o da un argomento tecnico indicato dall'utente.

## Quando usarla

- L'utente chiede un'agenda, un programma o un piano di corso.
- L'utente fornisce un documento tecnico, una policy o una procedura da trasformare in formazione.
- L'utente indica solo un argomento tecnico e una durata.

## Input da raccogliere

Leggi prima il documento sorgente, se presente. Ricava o chiedi solo i dati mancanti essenziali:

1. Argomento o documento sorgente
2. Destinatari e livello (base, intermedio, avanzato)
3. Durata totale e modalità (aula, online live, e-learning, blended)
4. Numero di partecipanti, lingua, docente, data e sede (se non noti, lasciare "Da definire")

Se l'utente non specifica un dato non essenziale, scegli un valore ragionevole, dichiaralo in una riga in fondo e prosegui. Fai al massimo una domanda, solo se manca durata o argomento.

## Struttura da produrre (template TPL-TRN-001)

1. **Scheda del corso**: titolo, codice, area tematica, livello, modalità, durata totale in ore, massimo partecipanti, lingua, docente, data e sede, documento sorgente
2. **Destinatari e prerequisiti**: profilo dei destinatari; prerequisiti solo se verificabili (competenze, strumenti, accessi), altrimenti "Nessun prerequisito"
3. **Obiettivi di apprendimento**: da 3 a 6, con verbo operativo + oggetto + condizione (spiegare, configurare, confrontare, applicare, risolvere). Evitare "conoscere" e "comprendere"
4. **Programma**: per ogni giornata, tabella con colonne Orario, Durata, Modulo, Contenuti, Metodo, Materiali. Include accoglienza e introduzione, moduli, esercitazioni, pause da 15 minuti, quiz intermedio e chiusura con feedback
5. **Dettaglio dei moduli**: per ogni modulo durata, obiettivo collegato, argomenti, attività proposta, punto di attenzione per il docente, fonte nel documento sorgente con sezione
6. **Matrice obiettivi, moduli e verifiche**: tabella Obiettivo, Modulo, Esercitazione, Domande quiz
7. **Verifica dell'apprendimento**: quiz finale (numero domande, durata, soglia), esercitazione conclusiva, criteri di valutazione, attestato
8. **Materiali e requisiti tecnici**: materiali per i partecipanti, requisiti tecnici, allestimento sala o ambiente online
9. **Follow-up**: questionario di gradimento, verifica a distanza, risorse di approfondimento, contatto post-corso

## Regole di costruzione

- Non superare 90 minuti consecutivi senza pausa.
- Rapporto indicativo 40% teoria e 60% pratica.
- Almeno un momento di verifica per giornata.
- Lasciare circa il 10% del tempo come margine.
- La somma delle durate deve coincidere con la durata totale dichiarata: calcolala davvero prima di consegnare.
- Ogni modulo è collegato ad almeno un obiettivo e ogni obiettivo ad almeno un modulo.
- Ogni contenuto deve essere riconducibile al documento sorgente, con riferimento alla sezione. Ciò che non è nel sorgente va dichiarato come integrazione.
- Livello e prerequisiti coerenti con la complessità dei contenuti.
- Non lasciare segnaposto `{{...}}` non compilati. I campi ignoti si scrivono "Da definire".
- Il codice corso, se non fornito, segue il formato CRS-AREA-NNN.

## Output

- Formato predefinito: documento Word (.docx) con titoli, tabelle con bordi e intestazione evidenziata. Se l'utente chiede Markdown, PDF o altro, usa quel formato.
- Rimuovere dal documento finale tutte le note di istruzione per l'agente.
- Chiudere con 1 o 2 righe di sintesi (durata totale, numero moduli, ipotesi fatte), senza ripetere il contenuto.

## Checklist finale (verificare prima di consegnare)

- [ ] La somma delle durate coincide con la durata totale
- [ ] Ogni obiettivo è misurabile e coperto da almeno una verifica
- [ ] Rapporto teoria e pratica rispettato
- [ ] Pause presenti e nessun blocco oltre 90 minuti
- [ ] Ogni contenuto è riconducibile al sorgente o dichiarato come integrazione
- [ ] Nessun segnaposto non compilato
- [ ] Livello e prerequisiti coerenti

## Collegamento con il quiz

Nella matrice e nella sezione verifiche cita gli identificativi delle domande del quiz. Se l'utente chiede anche il quiz, usa la skill `quiz-da-template` sullo stesso sorgente e mantieni gli stessi numeri di obiettivo.