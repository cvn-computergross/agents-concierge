---
name: cv-screening
description: "Applica un confronto trasparente, documentato e job-related tra CV accessibili e criteri forniti dall’utente."
---

# Skill: CV Screening

## Scopo
Supporta la revisione iniziale dei CV rispetto a criteri professionali espliciti. La valutazione è consultiva: non approvare, rifiutare o decidere l’assunzione di candidati.

## Passaggi
1. Identifica ruolo, requisiti obbligatori, preferenziali e informazioni che l’utente desidera confrontare. Se mancano criteri essenziali, chiedi chiarimento.
2. Usa esclusivamente CV e fonti realmente disponibili nel contesto. Cita o descrivi l’evidenza presente nel documento; se un dato non è riportato, indica `Non specificato`.
3. Per ogni candidato confronta ogni requisito in una matrice sintetica: requisito, evidenza nel CV, stato (`supportato`, `parzialmente supportato`, `non specificato`, `non supportato`). Non equiparare automaticamente anni di esperienza diversi e non dedurre competenze dal solo titolo di studio o dal nome del ruolo.
4. Riassumi le competenze pertinenti, l’esperienza documentata e le aree da verificare in colloquio. Evita punteggi numerici salvo richiesta esplicita e metodo trasparente basato solo su criteri job-related.
5. Se più candidati sono confrontati, applica gli stessi criteri e lo stesso livello di dettaglio a tutti. Non nascondere dati mancanti né presentare differenze marginali come conclusioni certe.
6. Chiudi ricordando che l’output è un supporto informativo e richiede revisione HR.

## Criteri esclusi
Non analizzare né inferire età, genere, etnia, religione, disabilità, salute, situazione familiare o altre caratteristiche sensibili. Non usare foto, nomi, indirizzi o segnali indiretti come proxy. Non formulare decisioni automatiche di assunzione o esclusione.

## Riservatezza
Riporta solo i dati personali necessari per la richiesta. Non copiare l’intero CV, inviarlo via email, condividerlo o salvarlo in un altro sistema. Se la fonte non è accessibile, dichiaralo invece di fingere una ricerca.
