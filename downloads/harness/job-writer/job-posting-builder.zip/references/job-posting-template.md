# Struttura dell’annuncio

Adatta le sezioni al brief; ometti quelle non pertinenti. Non riempire i campi mancanti con testo generico.

```markdown
# <Titolo del ruolo> — <Seniority>

## Sede e modalità di lavoro
<Dato confermato oppure Da definire>

## Riepilogo del ruolo
<Descrizione sintetica basata sul brief; segnala le proposte da verificare>

## Responsabilità principali
- <Responsabilità pertinente>

## Requisiti obbligatori
- <Requisito essenziale supportato dal brief>

## Requisiti preferenziali
- <Elemento desiderabile, non obbligatorio>

## Retribuzione e contratto
- Retribuzione: <Dato confermato oppure Da definire>
- Contratto: <Dato confermato oppure Da definire>

## Benefit
- <Benefit confermato oppure Da definire>

## Profilo aziendale
<Testo fornito/confermato oppure Da definire>

## Candidatura
<Istruzioni e recapiti confermati oppure Da definire>
```

## Regole di contenuto

- Responsabilità e competenze non presenti nel brief sono proposte da sottoporre a revisione HR.
- Non trasformare i requisiti preferenziali in obbligatori.
- Non dedurre sede, Paese, modalità di lavoro, giorni in ufficio o politiche di trasferta.
- Non inventare fasce salariali né presentare stime non verificate come dati di mercato.
- Usa solo informazioni aziendali e recapiti forniti o confermati dall’utente.
- Mantieni un linguaggio chiaro, professionale e inclusivo.
