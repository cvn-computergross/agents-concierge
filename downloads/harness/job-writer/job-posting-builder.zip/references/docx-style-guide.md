# Riferimento di stile DOCX

Lo script applica questo stile al documento:

- Margini da 0,7 a 0,8 pollici, corpo Aptos 10 pt.
- Titolo del ruolo in apertura; sede e modalità subito sotto.
- Sezioni con titoli blu ad alto contrasto e liste puntate per responsabilità e requisiti.
- Retribuzione e contratto presentati separatamente per facilitarne la revisione.
- Campi non disponibili esplicitati come `Da definire`, senza inventare contenuti.

Il risultato deve restare semplice da leggere e modificare in Microsoft Word; non aggiungere elementi grafici o branding non forniti dall’utente.
