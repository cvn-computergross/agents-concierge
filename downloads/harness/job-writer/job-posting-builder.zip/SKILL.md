---
name: job-posting-builder
description: "Raccoglie il brief HR, prepara annunci di lavoro accurati e genera documenti Word DOCX."
---

# Job Posting Builder

Usa questa skill per raccogliere un brief, preparare una bozza controllata di annuncio di lavoro e, quando richiesto, generare un documento Word `.docx`.

## Procedura

1. Raccogli titolo del ruolo, seniority e sede/modalità di lavoro. Riutilizza i dati già presenti e chiedi solo le informazioni essenziali che mancano.
2. Separa i dati confermati dalle proposte redazionali e dai campi da definire. Non inventare informazioni aziendali, retribuzione, contratto, benefit, politiche o istruzioni di candidatura.
3. Redigi l’annuncio seguendo `references/job-posting-template.md`. Distingui sempre i requisiti obbligatori da quelli preferenziali; usa un linguaggio professionale e inclusivo.
4. Prima della consegna, controlla coerenza con il brief, campi non confermati e possibili requisiti non pertinenti o discriminatori. Indica in modo conciso cosa HR deve verificare.

## Generazione Word

Quando l’utente chiede un file Word:

1. Usa `references/job-posting-input.example.json` come schema dei dati; sostituisci gli esempi con il brief effettivo. Mantieni `Da definire` per i campi non forniti.
2. Esegui `scripts/generate_job_posting.py` nella sandbox Python con `python-docx` già disponibile:

   ```text
   python scripts/generate_job_posting.py --input job_posting.json --output job_posting.docx
   ```

3. Verifica che `job_posting.docx` esista e abbia contenuto prima di consegnarlo. Restituisci il file creato; non chiedere all’utente di eseguire lo script.
4. Se la sandbox non rende accessibili direttamente i file del pacchetto, usa il contenuto dello script come sorgente nella sandbox. Se l’esecuzione fallisce, descrivi l’errore senza dichiarare il documento pronto.
5. Non mostrare lo script o il JSON all’utente, a meno che li chieda.

Consulta `references/docx-style-guide.md` per il formato atteso. Il DOCX non implica approvazione o pubblicazione dell’annuncio.
