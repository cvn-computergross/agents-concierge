"""Generate a formatted job-posting DOCX from a UTF-8 JSON brief."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor


PLACEHOLDER = "Da definire"


def display(value: Any) -> str:
    if value is None:
        return PLACEHOLDER
    if isinstance(value, str):
        return value.strip() or PLACEHOLDER
    return str(value)


def add_text_section(document: Document, heading: str, content: Any) -> None:
    document.add_heading(heading, level=1)
    document.add_paragraph(display(content))


def add_list_section(document: Document, heading: str, items: Any) -> None:
    document.add_heading(heading, level=1)
    if isinstance(items, str):
        items = [items]
    if not isinstance(items, list):
        items = []
    values = [display(item) for item in items if display(item) != PLACEHOLDER]
    if not values:
        document.add_paragraph(PLACEHOLDER)
        return
    for item in values:
        document.add_paragraph(item, style="List Bullet")


def create_job_posting(job: dict[str, Any], output_path: Path) -> Path:
    if not isinstance(job, dict):
        raise ValueError("Il JSON deve contenere un oggetto con i dati dell’annuncio.")

    title_text = display(job.get("title"))
    seniority = display(job.get("seniority"))
    if title_text == PLACEHOLDER or seniority == PLACEHOLDER:
        raise ValueError("I campi title e seniority sono obbligatori.")
    if output_path.suffix.lower() != ".docx":
        raise ValueError("Il file di output deve avere estensione .docx.")

    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

    document.styles["Normal"].font.name = "Aptos"
    document.styles["Normal"].font.size = Pt(10)
    document.styles["Heading 1"].font.color.rgb = RGBColor(31, 78, 121)

    role_title = f"{title_text} — {seniority}"
    title = document.add_heading(role_title, level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT

    location = display(job.get("location"))
    work_mode = display(job.get("work_mode"))
    if work_mode != PLACEHOLDER and work_mode.casefold() != location.casefold():
        location = f"{location} — {work_mode}"

    add_text_section(document, "Sede e modalità di lavoro", location)
    add_text_section(document, "Riepilogo del ruolo", job.get("summary"))
    add_list_section(document, "Responsabilità principali", job.get("responsibilities"))
    add_list_section(document, "Requisiti obbligatori", job.get("required"))
    add_list_section(document, "Requisiti preferenziali", job.get("preferred"))
    add_text_section(document, "Retribuzione", job.get("salary"))
    add_text_section(document, "Contratto", job.get("contract"))
    add_list_section(document, "Benefit", job.get("benefits"))
    add_text_section(document, "Profilo aziendale", job.get("company_profile"))
    add_text_section(document, "Candidatura", job.get("application"))

    document.core_properties.title = role_title
    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Genera un annuncio di lavoro in formato DOCX.")
    parser.add_argument("--input", required=True, type=Path, help="Percorso del brief JSON.")
    parser.add_argument("--output", default=Path("job_posting.docx"), type=Path, help="Percorso del DOCX.")
    args = parser.parse_args()

    with args.input.open("r", encoding="utf-8") as input_file:
        job = json.load(input_file)
    created_file = create_job_posting(job, args.output)
    print(f"DOCX creato: {created_file}")


if __name__ == "__main__":
    main()
