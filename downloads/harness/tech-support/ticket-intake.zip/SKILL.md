---
name: ticket-intake
description: Analizza la richiesta, raccoglie i dati per il ticket e assegna una priorità motivata prima di chiamare il workflow.
---

# Skill: Ticket Intake

## Scopo e contratto del workflow
Prepara un ticket IT e fornisci a **Create New Ticket** i tre input tecnici del trigger:

- `text` (Issue): titolo breve e concreto del problema.
- `text_1` (IssueDescription): descrizione sufficiente per la presa in carico.
- `text_2` (Priority): uno dei valori esatti `Low`, `Normal` o `Critical`.

Rispetta nomi e maiuscole. Non aggiungere input non richiesti dal workflow.

## Procedura

### 1. Verifica l’intento

- Procedi solo quando l’utente chiede esplicitamente di aprire un ticket o accetta l’escalation proposta.
- Una richiesta di diagnosi o di semplice assistenza non autorizza l’invio.
- Prima di chiamare il workflow, presenta il riepilogo dei tre valori e chiedi conferma.

### 2. Raccogli Issue e descrizione

Raccogli soltanto le informazioni mancanti. Se l’utente ha già fornito i dettagli, riutilizzali senza ripetere le domande.

- **Issue / `text`**: sintetizza il sintomo principale in un titolo specifico, senza attribuire una causa non verificata.
- **IssueDescription / `text_1`**: riporta, quando disponibili, servizio o dispositivo coinvolto, sintomo, momento d’inizio, messaggio di errore esatto, impatto sul lavoro, verifiche e tentativi già eseguiti, ed eventuale soluzione temporanea.
- Se un dato essenziale per descrivere o instradare il problema non è chiaro, fai una domanda mirata. Non inventare dati e non trasformare ipotesi in fatti.
- Non includere password, codici MFA, token o altri segreti. Se l’utente li condivide, escludili dal ticket.

### 3. Analizza e assegna Priority / `text_2`

Basa la priorità sull’impatto dichiarato dall’utente, non sul nome del problema o su supposizioni. Applica le definizioni della guida:

| Valore da inviare | Criterio |
| --- | --- |
| `Critical` | Il problema impedisce all’utente di lavorare. |
| `Normal` | Il lavoro è compromesso ma può proseguire; il problema richiede risoluzione entro 48 ore. |
| `Low` | Il problema è non bloccante e non richiede risoluzione entro 48 ore. |

- Valuta prima se l’utente è bloccato; poi valuta la possibilità di continuare a lavorare e l’urgenza entro 48 ore.
- Non assegnare `Critical` solo perché il problema è frustrante o importante: deve risultare che impedisce di lavorare.
- Se non è chiaro se l’utente può lavorare o se serve una risoluzione entro 48 ore, chiedi il chiarimento necessario prima di classificare.
- Nel riepilogo spiega in una frase quale impatto ha determinato la priorità. Non chiedere all’utente di scegliere il valore al posto dell’analisi; accogli però nuove informazioni e riclassifica se cambiano i fatti.

### 4. Controlla e conferma

Mostra un riepilogo in Markdown con i valori che saranno inviati:

```text
Issue (text): <titolo>
IssueDescription (text_1): <descrizione>
Priority (text_2): <Low | Normal | Critical>
```

Aggiungi una breve motivazione della priorità e chiedi conferma esplicita. Se l’utente corregge i dati, aggiorna il riepilogo e richiedi conferma prima dell’invio.

### 5. Invoca e comunica l’esito

- Dopo la conferma, chiama **Create New Ticket** una sola volta passando `text`, `text_1` e `text_2` con i valori confermati.
- Se il workflow segnala un altro campo obbligatorio, chiedi all’utente quel dato; non dedurlo e non inviare valori segnaposto.
- Se il workflow fallisce o l’esito è incerto, non riprovare automaticamente. Dichiara che la creazione non è confermata.
- Comunica che il ticket è stato creato e riporta il suo identificativo solo se il risultato dello strumento lo conferma esplicitamente.
